//
//  ViewController.swift
//  TableViewApp
//
//  Created by Manuja Prasadam on 3/28/24.
//

import UIKit


class Product{
    var productname:String?
    var productcategory:String?
    init(productname: String , productcategory: String) {
        
        self.productname = productname
        self.productcategory = productcategory
    }
}

class ViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        
        //return the number of products
        return Appleproducts.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        
        //create a cell
        var cell = tableViewOL.dequeueReusableCell(withIdentifier: "reusableCell", for: indexPath)
        
        //populate the cell
        cell.textLabel?.text = Appleproducts[indexPath.row].productname
        
        //return a cell
        return cell
    }
     
    
    
    @IBOutlet weak var tableViewOL: UITableView!
    
    var Appleproducts = [Product]()

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        let p1 = Product(productname: "iphone",productcategory: "Mobile phone")
        Appleproducts.append(p1)
        
        let p2 = Product(productname: "Macbook",productcategory: "laptop")
        Appleproducts.append(p2)
        
        let p3 = Product(productname: "earpods",productcategory: "apple device")
        Appleproducts.append(p3)
        
        let p4 = Product(productname: "iPad",productcategory: "Tablet")
        Appleproducts.append(p4)
        
        let p5 = Product(productname: "iwatch",productcategory: "Smart Watch")
        Appleproducts.append(p5)
        
        tableViewOL.delegate = self
        tableViewOL.dataSource = self
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        
        if(transition == "ProdDescriptionSegue"){
            
            let destination = segue.destination as! DescriptionViewController
            
            destination.product = Appleproducts[(tableViewOL.indexPathForSelectedRow?.row)!]
        }
    }


}

