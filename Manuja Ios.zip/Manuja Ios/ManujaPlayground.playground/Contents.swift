import UIKit
print("Hii",10,12.25)
var ProgrammingLanguage = "Swift"
print("My favorite Programming Language is \(ProgrammingLanguage)")
print("My favorite Programming language is " + ProgrammingLanguage)

var age = 23
print("you are \(age) years old and in another \(age) years, you will be \(age*2)")

print("""
Hello
World!
""")

print("Hello All, \nWelcome to swift programming")

let welcome : String = "Hello!"
print(welcome , "All")

print("My name is Manuja",terminator: "_")
print("Prasadam")

print("The list of numbers are ")
print(1,2,3,4,5,6,separator: "_")

// VARABLES AND CONSTANTS

var mobile = "Apple"
mobile = "Samsung"
print(mobile)

//explict diclaration
var a : Int = 23
a = a*2
print(a)

var c1 = "iOS"
var c2 = "java"
print(c1,"_",c2)

print(10,20)
print(12.5,15.5)

//TUPLES
var httperror = (errorcode : 404,errormessage : "page not found")
print(httperror)
print(httperror.errorcode, terminator: " : ")
print(httperror.errormessage)
print(type(of: httperror))

var name  = ("manuja","prasadam")
print(name.0, terminator: ",")
print(name.1)

var origin = (x : 1 , y : 2)
var point = origin
print(point)

let city = (name : "Maryville" , population : 11000)
let ( cityname , citypopulation ) = (city.0 , city.1)
print(cityname)
print(citypopulation)

let grocories = ("bread","onion")
print(grocories.0)
print(grocories.1)
print(type(of: grocories))

var fname = "prasadam"
var lname = "manuja"
(fname , lname) = (lname , fname)
print(fname)
print(lname)

var vegies = ("tomato" , "onions" , ("carrot" , "orange"))
print(vegies.1)
print(vegies.2.0)


