//
//  ViewController.swift
//  OmioBookingApp
//
//  Created by Manuja Prasadam on 4/4/24.
//

import UIKit

class LoginViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

