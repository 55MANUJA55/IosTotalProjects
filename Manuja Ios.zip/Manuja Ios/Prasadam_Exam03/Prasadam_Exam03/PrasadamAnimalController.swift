//
//  PrasadamAnimalController.swift
//  Prasadam_Exam03
//
//  Created by Manuja Prasadam on 4/18/24.
//

import UIKit



class PrasadamAnimalController: UIViewController {
    var animalname = ""
    var animaldescription = ""
    var animalimage : UIImage?

    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    
    
    @IBOutlet weak var nameOL: UILabel!
    
    
    @IBOutlet weak var descriptionOL: UITextView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        self.title = animalname
        
        nameOL.text = animalname
        imageViewOL.image = animalimage
        descriptionOL.text = animaldescription
        
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
