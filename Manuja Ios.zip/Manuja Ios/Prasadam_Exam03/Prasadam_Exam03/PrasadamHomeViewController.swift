//
//  ViewController.swift
//  Prasadam_Exam03
//
//  Created by Manuja Prasadam on 4/18/24.
//

import UIKit

class PrasadamHomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
      return animals.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = PrasadamTVOL.dequeueReusableCell(withIdentifier: "PrasadamCell", for: indexPath)
        cell.textLabel?.text = animals[indexPath.row].name
        return cell
    }
    

    
    @IBOutlet weak var PrasadamTVOL: UITableView!
    
    var animal = [Animal] ()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
        PrasadamTVOL.delegate = self
        PrasadamTVOL.dataSource = self
        
        self.title = "Animals"
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if(transition == "PrasadamDescriptionSegue"){
            let destination = segue.destination as! PrasadamAnimalController
            let index = PrasadamTVOL.indexPathForSelectedRow
            destination.animalname = animals[index!.row].name!
            destination.animaldescription = animals[index!.row].information!
            destination.animalimage = animals[index!.row].imageName!
            
        }
        
    }


}

