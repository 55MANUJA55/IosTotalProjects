import UIKit

var fact = "Swift is a type safe language"
var dev = "Development of Swift began in 2010"
var author = "Swift was created by Chris Lattner"

print(fact.count)
fact+=", it has a better memory management"
print(fact)
dev.append(" by Apple")
print(dev)

print(author.uppercased())
print(author.lowercased())

print(author[author.startIndex])

print(author[author.index(before: author.endIndex)])

print(dev[dev.startIndex])
print(dev[dev.index(before: dev.endIndex)])

print(author[author.index(after: author.startIndex)])
print(author[author.index(author.startIndex,offsetBy: 5)])
print(author[author.index(author.endIndex,offsetBy: -5)])
print(fact[fact.index(fact.endIndex,offsetBy: -4)])

//worksheet 2

var shoppingList = "The shopping list contains: "
var foodItems = "Cheese, Butter, Chocolate Spread"
var cloths = "Socks, T-shirts"

if cloths.hasPrefix("Socks") {
print("The first item in clothes is socks")
}else{
print("socks is not the first item in clothes")
}

print(foodItems.split(separator: ","))

if cloths.contains(","){
    print("Cloths contain more than one element")
}else{
    print("Cloths contain only one item")
}

print(foodItems[foodItems.startIndex..<foodItems.index(foodItems.endIndex,offsetBy: -7)])
shoppingList += foodItems[foodItems.index(foodItems.startIndex , offsetBy: 8)..<foodItems.endIndex]
print(shoppingList)
print(cloths.remove(at: cloths.firstIndex(of: "T")!))

print(cloths.remove(at: cloths.firstIndex(of: "-")!))
print("\(shoppingList), \(cloths)")
cloths.insert(contentsOf: ", Trousers", at: cloths.endIndex)
 print(cloths)

//worksheet 3

var course = "44643-Mobile Computing-iOS"
//displaying only course number

print(course[course.startIndex..<course.firstIndex(of: "-")!])

//displaying only course title

//print(course[course.index(course.endIndex,offsetBy: -20)])
