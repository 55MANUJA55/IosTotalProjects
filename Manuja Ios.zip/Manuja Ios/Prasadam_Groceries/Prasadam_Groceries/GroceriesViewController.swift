//
//  GroceriesViewController.swift
//  Prasadam_Groceries
//
//  Created by Manuja Prasadam on 4/16/24.
//

import UIKit

class GroceriesViewController: UIViewController, UICollectionViewDelegate, UICollectionViewDataSource {
    func collectionView(_ collectionView: UICollectionView, numberOfItemsInSection section: Int) -> Int {
        return category.count
    }
    
    func collectionView(_ collectionView: UICollectionView, cellForItemAt indexPath: IndexPath) -> UICollectionViewCell {
        let cell = collectionView.dequeueReusableCell(withReuseIdentifier: "itemCell", for: indexPath) as! ItemCollectionViewCell
               
               cell.categorieImage(cat: category[indexPath.row])
               
               return cell
    }
    
    
    
   
    
    func collectionView(_ collectionView: UICollectionView, didSelectItemAt indexPath: IndexPath) {
        
        
        categorieDetails(index: indexPath)
    
    }
    
    func categorieDetails(index: IndexPath){
        itemNameLabel.text = "Product Name: \(category[index.row].itemName)"
        itemPriceLabel.text = "Price: \(category[index.row].itemPrice)"
        itemExpireLabel.text = "Expires on: \(category[index.row].itemExpiry)"
        itemDescriptionLabel.text = "Description: \(category[index.row].itemDescription)"
        itemQuantityLabel.text = "Quantity: \(category[index.row].itemQuantity)"
        itemOriginLabel.text = "Origin: \(category[index.row].itemOrigin)"
    }
    
    
   

    
    @IBOutlet weak var itemCollectionView: UICollectionView!
    
    
    @IBOutlet weak var itemNameLabel: UILabel!
    
    
    @IBOutlet weak var itemPriceLabel: UILabel!
    
    
    @IBOutlet weak var itemExpireLabel: UILabel!
    
    
    @IBOutlet weak var itemDescriptionLabel: UILabel!
    
    @IBOutlet weak var itemQuantityLabel: UILabel!
    
    @IBOutlet weak var itemOriginLabel: UILabel!
    
    var category: [Item] = []
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        itemCollectionView.delegate = self
        itemCollectionView.dataSource = self
        
        itemNameLabel.text = "Product Name: \(category[0].itemName)"
        itemPriceLabel.text = "Price: \(category[0].itemPrice)"
        itemExpireLabel.text = "Expires on: \(category[0].itemExpiry)"
        itemDescriptionLabel.text = "Description: \(category[0].itemDescription)"
        itemQuantityLabel.text = "Quantity: \(category[0].itemQuantity)"
        itemOriginLabel.text = "Origin: \(category[0].itemOrigin)"

        
    
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
