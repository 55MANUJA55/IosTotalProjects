//
//  ItemCollectionViewCell.swift
//  Prasadam_Groceries
//
//  Created by Manuja Prasadam on 4/16/24.
//

import UIKit




class ItemCollectionViewCell: UICollectionViewCell {
    
    @IBOutlet weak var imageOL: UIImageView!
    
    
    func categorieImage(cat : Item){
        imageOL.image = cat.image
    }
    
}
