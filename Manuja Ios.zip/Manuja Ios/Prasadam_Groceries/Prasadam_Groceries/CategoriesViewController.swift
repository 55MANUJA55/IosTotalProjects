//
//  ViewController.swift
//  Prasadam_Groceries
//
//  Created by Manuja Prasadam on 4/16/24.
//

import UIKit

class CategoriesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
  
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return categories.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = categoryTableViewOL.dequeueReusableCell(withIdentifier: "categoryCell", for: indexPath)
        cell.textLabel?.text = categoryNames[indexPath.row]
        
        return cell
    }
    

    @IBOutlet weak var categoryTableViewOL: UITableView!
    
    let categories = allCategories
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        categoryTableViewOL.dataSource = self
        categoryTableViewOL.delegate = self
        self.title = "Categories"
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if transition == "groceriesSegue"{
            let destination = segue.destination as! GroceriesViewController
            let index = categoryTableViewOL.indexPathForSelectedRow
            destination.category = allCategories[index!.row]
        }
    }
    


}

