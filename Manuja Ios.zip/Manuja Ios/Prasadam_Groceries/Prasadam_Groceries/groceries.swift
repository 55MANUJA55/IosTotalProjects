//
//  groceries.swift
//  Prasadam_Groceries
//
//  Created by Manuja Prasadam on 4/16/24.
//

import Foundation
import UIKit

struct Item{
    var itemName : String
    var image : UIImage
    var itemPrice : Double
    var itemExpiry : String
    var itemDescription : String
    var itemQuantity : Int
    var itemOrigin : String
    
}
let allCategories: [[Item]] = [Fruits,Vegitables,CoolDrinks,IceCreams,Chacolates]
let categoryNames: [String] = ["Fruits","Vegitables","Cool Drinks","Ice Creams","Chacolates"]

let Fruits: [Item] = [
    Item(itemName: "muskmelon", image: UIImage(named: "a10")!, itemPrice: 3.19, itemExpiry: "2024-04-19", itemDescription: "Muskmelon is native to Persia.", itemQuantity: 2, itemOrigin: "Iran"),
    Item(itemName: "Apple", image: UIImage(named: "a1")!, itemPrice: 5.29, itemExpiry: "2024-04-25", itemDescription: "Apples are not native to North America.", itemQuantity: 5, itemOrigin: "Kazakhstan"),
    Item(itemName: "Pineapple", image: UIImage(named: "a6")!, itemPrice: 2.50, itemExpiry: "2024-04-18", itemDescription: "it is originated from South America.", itemQuantity: 1, itemOrigin: "America"),
    Item(itemName: "Banana", image: UIImage(named: "a2")!, itemPrice: 2.00, itemExpiry: "2024-04-22", itemDescription: "good for digestion.", itemQuantity: 7, itemOrigin: "India"),
    Item(itemName: "Orange", image: UIImage(named: "a3")!, itemPrice: 4.00, itemExpiry: "2024-04-24", itemDescription: "Jucie Orange.", itemQuantity: 12, itemOrigin: "China"),
    Item(itemName: "Strawberry", image: UIImage(named: "a4")!, itemPrice: 6.00, itemExpiry: "2024-04-28", itemDescription: "origins of strawberry plants are widely unknown.", itemQuantity: 17, itemOrigin: "America"),
    Item(itemName: "Grapes", image: UIImage(named: "a5")!, itemPrice: 2.00, itemExpiry: "2024-04-20", itemDescription: "Sweetest grapes.", itemQuantity: 50, itemOrigin: "Iran"),
    Item(itemName: "Watermelon", image: UIImage(named: "a7")!, itemPrice: 8.98, itemExpiry: "2024-04-19", itemDescription: "Jucie watermelon.", itemQuantity: 1, itemOrigin: "Africa"),
    Item(itemName: "Mango", image: UIImage(named: "a8")!, itemPrice: 1.90, itemExpiry: "2024-04-29", itemDescription: "Seasonal Fruits", itemQuantity: 1, itemOrigin: "India"),
    Item(itemName: "Kiwi", image: UIImage(named: "a9")!, itemPrice: 2.60, itemExpiry: "2024-04-17", itemDescription: "Healthy Fruit.", itemQuantity: 5, itemOrigin: "China")]

let Vegitables: [Item] = [
    Item(itemName: "Tomato", image: UIImage(named: "b1")!, itemPrice: 2.98, itemExpiry: "2024-04-25", itemDescription: "First cultivated tomato was yellow.", itemQuantity: 15, itemOrigin: "South America"),
    Item(itemName: "Onions", image: UIImage(named: "b2")!, itemPrice: 3.98, itemExpiry: "2024-05-07", itemDescription: "Very Essential Ingrediant.", itemQuantity: 7, itemOrigin: "Central Asia"),
    Item(itemName: "Potato", image: UIImage(named: "b3")!, itemPrice: 2.50, itemExpiry: "2024-05-18", itemDescription: "Strachy root.", itemQuantity: 10, itemOrigin: "India"),
    Item(itemName: "Carrot", image: UIImage(named: "b4")!, itemPrice: 1.00, itemExpiry: "2024-05-04", itemDescription: "Colourful roots.", itemQuantity: 9, itemOrigin: "Afghanistan"),
    Item(itemName: "Brinjal", image: UIImage(named: "b5")!, itemPrice: 2.00, itemExpiry: "2024-04-17", itemDescription: "Also called eggplant.", itemQuantity: 1, itemOrigin: "Asian"),
    Item(itemName: "Capsicum", image: UIImage(named: "b6")!, itemPrice: 3.00, itemExpiry: "2024-04-28", itemDescription: "It have different names.", itemQuantity: 4, itemOrigin: "Brazil"),
    Item(itemName: "Cauliflower", image: UIImage(named: "b7")!, itemPrice: 5.00, itemExpiry: "2024-05-20", itemDescription: "Annual Plants.", itemQuantity: 1, itemOrigin: "Asia"),
    Item(itemName: "Cabbage", image: UIImage(named: "b8")!, itemPrice: 6.98, itemExpiry: "2024-05-19", itemDescription: "It is a leafy green.", itemQuantity: 1, itemOrigin: "Europe"),
    Item(itemName: "Ladys Finger", image: UIImage(named: "b9")!, itemPrice: 8.90, itemExpiry: "2024-04-29", itemDescription: "Short Branching stems.", itemQuantity: 20, itemOrigin: "Africa"),
    Item(itemName: "Ivy gourd", image: UIImage(named: "b10")!, itemPrice: 2.60, itemExpiry: "2024-05-17", itemDescription: "small trees.", itemQuantity: 25, itemOrigin: "Africa")]




let CoolDrinks: [Item] = [
    Item(itemName: "ThumsUp", image: UIImage(named: "c1")!, itemPrice: 2.00, itemExpiry: "2025-04-25", itemDescription: "Carbonated Water.", itemQuantity: 1, itemOrigin: "India"),
    Item(itemName: "7UP", image: UIImage(named: "c2")!, itemPrice: 2.98, itemExpiry: "2025-05-07", itemDescription: "Soft Drink.", itemQuantity: 1, itemOrigin: "ST.Louis"),
    Item(itemName: "Sprite", image: UIImage(named: "c3")!, itemPrice: 2.50, itemExpiry: "2025-05-18", itemDescription: "Created by cocacola.", itemQuantity: 1, itemOrigin: "Germany"),
    Item(itemName: "Maaza", image: UIImage(named: "c4")!, itemPrice: 3.00, itemExpiry: "2026-05-04", itemDescription: "Mango drink.", itemQuantity: 1, itemOrigin: "India"),
    Item(itemName: "Slice", image: UIImage(named: "c5")!, itemPrice: 2.00, itemExpiry: "2025-04-17", itemDescription: "Manufactured by pepsiCo", itemQuantity: 1, itemOrigin: "America"),
    Item(itemName: "Mirinda", image: UIImage(named: "c6")!, itemPrice: 3.00, itemExpiry: "2026-04-28", itemDescription: "Soft Drink.", itemQuantity: 1, itemOrigin: "Spain"),
    Item(itemName: "Coke", image: UIImage(named: "c7")!, itemPrice: 5.00, itemExpiry: "2027-06-20", itemDescription: "Temperance Drink.", itemQuantity: 1, itemOrigin: "Georgia"),
    Item(itemName: "Mountain dew", image: UIImage(named: "c8")!, itemPrice: 4.98, itemExpiry: "2025-12-19", itemDescription: "It is a mixer drink.", itemQuantity: 1, itemOrigin: "Tennessee"),
    Item(itemName: "Lemonade", image: UIImage(named: "c9")!, itemPrice: 1.90, itemExpiry: "2024-04-29", itemDescription: "Fresh Drink.", itemQuantity: 1, itemOrigin: "America"),
    Item(itemName: "Pulpy Orange", image: UIImage(named: "c10")!, itemPrice: 2.60, itemExpiry: "2025-05-17", itemDescription: "Orange drink.", itemQuantity: 1, itemOrigin: "India")]




let IceCreams: [Item] = [
    Item(itemName: "Chacolate", image: UIImage(named: "d1")!, itemPrice: 4.00, itemExpiry: "2024-05-25", itemDescription: "frozen chacolate", itemQuantity: 1, itemOrigin: "Italy"),
    Item(itemName: "Vanilla", image: UIImage(named: "d2")!, itemPrice: 3.98, itemExpiry: "2025-05-07", itemDescription: "Cooling mixer.", itemQuantity: 1, itemOrigin: "India"),
    Item(itemName: "Strawberry", image: UIImage(named: "d3")!, itemPrice: 12.50, itemExpiry: "2026-04-18", itemDescription: "It is a dessert.", itemQuantity: 1, itemOrigin: "Maryland"),
    Item(itemName: "Oreo", image: UIImage(named: "d4")!, itemPrice: 3.00, itemExpiry: "2026-05-04", itemDescription: "Made with oreo biscuits.", itemQuantity: 1, itemOrigin: "Africa"),
    Item(itemName: "Butterscotch", image: UIImage(named: "d5")!, itemPrice: 20.00, itemExpiry: "2026-05-17", itemDescription: "Brown sugar and butter", itemQuantity: 1, itemOrigin: "Scotland"),
    Item(itemName: "Blueberry", image: UIImage(named: "d6")!, itemPrice: 7.00, itemExpiry: "2024-04-28", itemDescription: "Fruite icecream.", itemQuantity: 1, itemOrigin: "America"),
    Item(itemName: "Cone", image: UIImage(named: "d7")!, itemPrice: 5.00, itemExpiry: "2027-06-20", itemDescription: "made with fruit.", itemQuantity: 1, itemOrigin: "Georgia"),
    Item(itemName: "Watermelon", image: UIImage(named: "d8")!, itemPrice: 4.98, itemExpiry: "2026-12-19", itemDescription: "Good for health.", itemQuantity: 1, itemOrigin: "India"),
    Item(itemName: "Coconut", image: UIImage(named: "d9")!, itemPrice: 2.90, itemExpiry: "2025-04-29", itemDescription: "Sweet and cool.", itemQuantity: 1, itemOrigin: "India"),
    Item(itemName: "KitKat", image: UIImage(named: "d10")!, itemPrice: 2.60, itemExpiry: "2025-07-07", itemDescription: "Chacolate Ice cream.", itemQuantity: 1, itemOrigin: "Spain")]




let Chacolates: [Item] = [
    Item(itemName: "Dairy Milk", image: UIImage(named: "e1")!, itemPrice: 3.19, itemExpiry: "2026-04-19", itemDescription: "manufactured by cadbury.", itemQuantity: 1, itemOrigin: "British"),
    Item(itemName: "5star", image: UIImage(named: "e2")!, itemPrice: 15.29, itemExpiry: "2024-04-25", itemDescription: "comedy ad in TV.", itemQuantity: 5, itemOrigin: "India"),
    Item(itemName: "KitKat", image: UIImage(named: "e3")!, itemPrice: 2.50, itemExpiry: "2025-04-18", itemDescription: "Chacolate crisp.", itemQuantity: 1, itemOrigin: "England"),
    Item(itemName: "Snickers", image: UIImage(named: "e4")!, itemPrice: 20.00, itemExpiry: "2026-04-22", itemDescription: "made with Peanuts.", itemQuantity: 7, itemOrigin: "India"),
    Item(itemName: "Dreamy delights", image: UIImage(named: "e5")!, itemPrice: 4.00, itemExpiry: "2027-04-24", itemDescription: "Creamy chacolate.", itemQuantity: 1, itemOrigin: "China"),
    Item(itemName: "Mahalacto", image: UIImage(named: "e6")!, itemPrice: 16.00, itemExpiry: "2024-04-28", itemDescription: "Childhood chacolate.", itemQuantity: 3, itemOrigin: "India"),
    Item(itemName: "Kaccha Mango", image: UIImage(named: "e7")!, itemPrice: 2.00, itemExpiry: "2025-04-20", itemDescription: "Sweet and spicy.", itemQuantity: 5, itemOrigin: "India"),
    Item(itemName: "Dark Chacolate", image: UIImage(named: "e8")!, itemPrice: 8.98, itemExpiry: "2026-04-19", itemDescription: "Sour and sweet.", itemQuantity: 1, itemOrigin: "America"),
    Item(itemName: "Kisses", image: UIImage(named: "e9")!, itemPrice: 4.90, itemExpiry: "2027-05-29", itemDescription: "By hershey cxhacolate", itemQuantity: 1, itemOrigin: "Pennsylvania"),
    Item(itemName: "Munch", image: UIImage(named: "e10")!, itemPrice: 2.60, itemExpiry: "2025-04-17", itemDescription: "Crispy and Crunchy", itemQuantity: 5, itemOrigin: "China")]
                                                                                                                                                                                                                                                                                         
                                                                                                                                                                                                                
