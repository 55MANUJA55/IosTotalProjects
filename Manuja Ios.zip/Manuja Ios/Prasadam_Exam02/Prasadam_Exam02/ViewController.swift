//
//  ViewController.swift
//  Prasadam_Exam02
//
//  Created by Manuja Prasadam on 4/11/24.
//

import UIKit

var mbp = 0.00
var diastolic = 0
var systolic = 0
var result = ""
var image = ""
var tip = ""
var id = ""
var mp = ""
var mbp2 = 0.00

class ViewController: UIViewController {
    
    @IBOutlet weak var patientOL: UITextField!
    
    
    @IBOutlet weak var sysOL: UITextField!
    
    
    @IBOutlet weak var diaOL: UITextField!
    

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


    @IBAction func checkBtn(_ sender: Any) {
        systolic =  Int(sysOL.text!)!
        diastolic = Int(diaOL.text!)!
        mbp = (0.667 * Double(diastolic))
        var mbp1 = (0.334 * Double(systolic))
        mbp2 = mbp + mbp1
        
        
        if(mbp2 < 60){
            id = "Patient ID: \(patientOL.text!)"
            mp = "Blood Pressure:\(systolic)/\(diastolic) mm Hg"
            result = "Result : Stroke or Internal Bleeding"
            image = "stroke"
            tip = "Health Tip: Seek immediate medical Attention. 👨🏻‍⚕️"
            
        }
        else if(mbp2 == 60 || mbp < 69){
            id = "Patient ID: \(patientOL.text!)"
            mp = "Blood Pressure:\(systolic)/\(diastolic)"
            result = "Result : Hypotension"
            image = "hypotension"
            tip = "Health Tip:Stay Hydrated 🥛"
            mbp2 = "MBP : \(mbp2)"
            
        }
        else if(mbp2 == 70 || mbp < 99){
            id = "Patient ID: \(patientOL.text!)"
            mp = "Blood Pressure:\(systolic)/\(diastolic)"
            result = "Result : Healthy"
            image = "healthy"
            tip = "Health Tip:You are doing great 👍"
            
        }
        else if(mbp2 == 100 || mbp < 106){
            id = "Patient ID: \(patientOL.text!)"
            mp = "Blood Pressure:\(systolic)/\(diastolic)"
            result = "Result : Elevated"
            image = "elevated"
            tip = "Health Tip:Make sure to maintain workout 🏋️"
            
        }
        else if(mbp2 >= 107){
            id = "Patient ID: \(patientOL.text!)"
            mp = "Blood Pressure:\(systolic)/\(diastolic)"
            result = "Result : Hypertension"
            image = "hypertension"
            tip = "Health Tip:Consult doctor for medication tab 💊"
            
        }
        
        
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        
        if(transition == "resultSegue"){
            let destination = segue.destination as! ResultViewController
            destination.image = image
            destination.result = result
            destination.tip = tip
            destination.id = id
            destination.mp = mp
            destination.mbp2 = mbp2
        }
    }
    
    
    
}

