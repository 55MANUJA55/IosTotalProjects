//
//  ResultViewController.swift
//  Prasadam_Exam02
//
//  Created by Manuja Prasadam on 4/11/24.
//

import UIKit

class ResultViewController: UIViewController {

    
    @IBOutlet weak var imgOL: UIImageView!
    
    
    @IBOutlet weak var idOL: UILabel!
    
    
    @IBOutlet weak var bpOL: UILabel!
    
    
    @IBOutlet weak var mbpOL: UILabel!
    
    
    @IBOutlet weak var resultOL: UILabel!
    
    
    @IBOutlet weak var tipOL: UILabel!
    
    
    
    var mp = ""
    var mbp2  = 0.00
    var result = ""
    var image = ""
    var tip = ""
    var id = ""
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        imgOL.image = UIImage(named: image)
        idOL.text = id
        bpOL.text = mp
        mbpOL.text = String(mbp2)
        resultOL.text = result
        tipOL.text = tip
        
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
