//
//  ViewController.swift
//  WordGuessApp
//
//  Created by Manuja Prasadam on 2/27/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var displayLabelOL: UILabel!
    
    @IBOutlet weak var HintLabelOL: UILabel!
    
    @IBOutlet weak var TextOL: UITextField!
    
    @IBOutlet weak var checkOL: UIButton!
    
    @IBOutlet weak var StatusLabelOL: UILabel!
    
    @IBOutlet weak var playAgainOL: UIButton!
    
    var words = [["JAVA","Programming Language"],["HORSE","Animal"],["Auto","Three Wheeler"],["Watch","Using to see Time"],["Pen","Using to Write"]]
    
    var count = 0;
    var word = ""
    var letterGuess = ""
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        //Check button should be disabled
        checkOL.isEnabled = false;
        
        //get first word from the array
        
        word = words[count][0]
        
        displayLabelOL.text = ""
        
        //populate the display label with the underscores. the # of underscore is equal to the # of characters in the word
        //updateUnderScores();
        
        // get the first hint from array
        HintLabelOL.text = "Hint : "+words[count][1]
        
        //clear status label initially
        StatusLabelOL.text = ""
    }

    @IBAction func TextChange(_ sender: Any) {
    }
    
    @IBAction func checkBtn(_ sender: Any) {
        
    //get the text from text field
        var letter = TextOL.text!
        
        //replace the guessed letter if the letter is part of the word
        
        letterGuess = letterGuess + letter
        
        var revealedWord = " "
        for m in word{
            
        }
        
        
    }
    
    @IBAction func playBtn(_ sender: Any) {
    }
    
}

