//
//  ViewController.swift
//  Prasadam_TravelBooking
//
//  Created by Manuja Prasadam on 4/1/24.
//

import UIKit

class BookingViewController: UIViewController {

    @IBOutlet weak var TravellerNameOL: UITextField!
    
    @IBOutlet weak var noOfTravellersOL: UITextField!
    
    @IBOutlet weak var cabinTypeOL: UITextField!
    
    
    var result = ""
    var image = ""
    var travName = ""
    var travellerCount : Int = 0
    var seatType = ""
    var total : Double = 0.0
    var name = ""
    var scount = ""
    var cabin = ""
    var seatCost = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func bookNowButton(_ sender: Any) {
        
        travName = TravellerNameOL.text!
        travellerCount = Int(noOfTravellersOL.text!)!
        seatType = cabinTypeOL.text!
        
        if(seatType.lowercased() == "economy"){
            total = Double(travellerCount * 125)
            result = "Hello \(travName), your Booking is Confirmed, "
            name = "Name: \(travName)"
            scount = "Number of Travellers: \(travellerCount)"
            cabin = "Cabin Class: \(seatType)"
            seatCost = "Total: \(total)$"
            image = "economyy"
            
        }
        else if(seatType.lowercased() == "luxury"){
            total = Double(travellerCount * 200)
            result = "Hello \(travName), your Booking is Confirmed, "
            name = "Name: \(travName)"
            scount = "Number of Travellers: \(travellerCount)"
            cabin = "Cabin Class: \(seatType)"
            seatCost = "Total: \(total)$"
            image = "luxuary"
            
        }
        else{
            image = "bus"
            result = "There is no selected class. Please choose a valid class."
            name = ""
            scount = ""
            cabin = ""
            seatCost = ""
        }
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transaction = segue.identifier
        
        if(transaction == "resultSegue"){
            let destination = segue.destination as! ResultViewController
            destination.image = image
            destination.result = result
            destination.name = name
            destination.scount = scount
            destination.cabin = cabin
            destination.seatCost = seatCost
            
            
        }
    }
    
    
}

