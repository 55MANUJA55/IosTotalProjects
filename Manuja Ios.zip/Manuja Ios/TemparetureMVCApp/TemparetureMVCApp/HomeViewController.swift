//
//  ViewController.swift
//  TemparetureMVCApp
//
//  Created by Manuja Prasadam on 3/25/24.
//

import UIKit

class HomeViewController: UIViewController {

    @IBOutlet weak var textOL: UITextField!
    var result = ""
    var image = ""
    var temperature: Double = 0.0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
    }

    @IBAction func btnClicked(_ sender: Any) {
        temperature  = Double(textOL.text!)!
       //ckeck the weather(hot or cold)
       if(temperature<60){
            result = "It is cold"
            image = "cool"
       }
       else
       {
            result = "It is Hot"
            image = "hot"
       }
   }
   override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
       //know the identifier
       let transition = segue.identifier
       //set the destination
       if(transition == "resultSegue"){
           let destination  = segue.destination as! ResultViewController
           //assign the values to the destination variables
           destination.image = image
           destination.result = result
           destination.temperature = temperature
       }
   }
    
    
}

