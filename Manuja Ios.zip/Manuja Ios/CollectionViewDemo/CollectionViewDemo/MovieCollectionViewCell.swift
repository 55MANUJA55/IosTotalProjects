//
//  MovieCollectionViewCell.swift
//  CollectionViewDemo
//
//  Created by Manuja Prasadam on 4/2/24.
//

import UIKit

class MovieCollectionViewCell: UICollectionViewCell {
    
    
    @IBOutlet weak var imageViewOL: UIImageView!
    

    func assignedMovie(with movie:Movie){
        imageViewOL.image = movie.image
    }
}
