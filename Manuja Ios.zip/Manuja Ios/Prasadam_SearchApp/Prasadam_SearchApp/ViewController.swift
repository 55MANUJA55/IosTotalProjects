//
//  ViewController.swift
//  Prasadam_SearchApp
//
//  Created by Manuja Prasadam on 3/17/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var searchTextField: UITextField!
    
    @IBOutlet weak var resultImage: UIImageView!
    
    
    
    @IBOutlet weak var searchOL: UIButton!
    
    
    @IBOutlet weak var nextOL: UIButton!
    
    
    @IBOutlet weak var resetOL: UIButton!
    
    
    @IBOutlet weak var prevOL: UIButton!
    

    
    @IBOutlet weak var topicInfoText: UITextView!
    
    
    
    var imageNum = 0;
    var topic: Int = -1
    var count : Int = -1
          
    var arr = [["Harry potter", "Titanic", "Half girlfriend", "Pirates of caribbean", "Escape-Room"], ["Surya", "Mahesh","Ram", "Ranbir", "vicky"], ["Dog", "Rabbit", "deer", "panda", "Penguin"]]
    var books_keywords = ["Harry potter", "Titanic", "Half girlfriend", "Pirates of Caribbean", "Escape-Room", "books", "Books", "book"]
    var actors_keywords = ["Surya", "Mahesh","Ram", "ram","Ranbir", "Vicky", "actors", "Actors", "actor"]
    var animals_keywords = ["Dog", "Rabbit", "deer", "panda", "Penguin","animals","Animals","animal"]
      
    var topics_array = [[
        "Adaptation of the first of J.K. Rowling's popular children's novels about Harry Potter, a boy who learns on his eleventh birthday that he is the orphaned son of two powerful wizards and possesses unique magical powers of his own.",
        "Titanic, launched on May 31, 1911, and set sail on its maiden voyage from Southampton on April 10, 1912, with 2,240 passengers and crew on board.",
        "A boy meets a girl named Riya and falls in love. After struggling to convince her to be his girlfriend, she half-heartedly agrees to be his `half-girlfriend'.",
        "Will Turner (Orlando Bloom) and Elizabeth Swann (Keira Knightley) join forces with Capt.",
        "Six adventurous strangers travel to a mysterious building to experience the escape room -- a game where players compete to solve a series of puzzles to win $10,000."],
        ["Saravanan Sivakumar (born 23 July 1975), known by his stage name Suriya, is an Indian actor, producer, television presenter and a philanthropist.",
         "Ghattamaneni Mahesh Babu (born 9 August 1975) is an Indian actor, producer, media personality, and philanthropist who works mainly in Telugu cinema.",
         "Ram Pothineni (born 15 May 1988) is an Indian actor who primarily works in Telugu films. He made his acting debut with the box office success Devadasu (2006), for which he won Filmfare Award for Best Male Debut – South.",
         "Ranbir Kapoor(born 28 September 1982) is an Indian actor known for his work in Hindi-language films.",
         "Vicky Kaushal(born 16 May 1988) is an Indian actor known for his work in Hindi films. Kaushal is the recipient of numerous accolades including a National Film Award and two Filmfare Awards, and has appeared in Forbes India's Celebrity 100 list of 2019."],
        ["The dog (Canis familiaris or Canis lupus familiaris) is a domesticated descendant of the wolf.",
         "Rabbits, also known as bunnies or bunny rabbits, are small mammals in the family Leporidae (which also contains the hares) of the order Lagomorpha (which also contains the pikas).",
         "Deer or true deer are hoofed ruminant mammals forming the family Cervidae.",
         "The giant panda (Ailuropoda melanoleuca, sometimes panda bear or simply panda) is a bear species endemic to China.It is characterised by its bold black-and-white coat and rotund body. ",
         "Penguins are a group of aquatic flightless birds. They live almost exclusively in the Southern Hemisphere: only one species, the Galápagos penguin, is found north of the Equator."]]
      
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        resultImage.image = UIImage(named: "welcome")
        searchOL.isEnabled = false
        prevOL.isHidden = true
        nextOL.isHidden = true
        resetOL.isHidden = true
    }

    @IBAction func searchButtonAction(_ sender: Any) {
       
        searchOL.isEnabled = true
                let a = searchTextField.text!
                count = 0
                if(books_keywords.contains(a)){
                    prevOL.isHidden = false
                    nextOL.isHidden = false
                    resetOL.isHidden = false
                    topicInfoText.isHidden = false;
                    topic = 0
                    resultImage.image = UIImage(named: arr[topic][count])
                    topicInfoText.text = topics_array[topic][count]
                    if(count==0){
                        prevOL.isEnabled = false
                        
                    }
                    else{
                        prevOL.isEnabled = true
                        
                    }
                    if(count == arr[topic].count-1){
                        nextOL.isEnabled = false
                        
                    }
                    else{
                        nextOL.isEnabled = true
                        
                    }
                    resetOL.isEnabled = true
                }
                else if(actors_keywords.contains(a)){
                    prevOL.isHidden = false
                    nextOL.isHidden = false
                    resetOL.isHidden = false
                    topicInfoText.isHidden = false;
                    topic = 1
                    resultImage.image = UIImage(named: arr[topic][count])
                    topicInfoText.text = topics_array[topic][count]
                    if(count==0){
                        prevOL.isEnabled = false
                        
                    }
                    else{
                        prevOL.isEnabled = true
                        
                    }
                    if(count == arr[topic].count-1){
                        nextOL.isEnabled = false
                        
                    }
                    else{
                        nextOL.isEnabled = true
                        
                    }
                    resetOL.isEnabled = true
                }
               else if(animals_keywords.contains(a)){
                   prevOL.isHidden = false
                   nextOL.isHidden = false
                   resetOL.isHidden = false
                   topicInfoText.isHidden = false;
                    topic = 2
                   resultImage.image = UIImage(named: arr[topic][count])
                   topicInfoText.text = topics_array[topic][count]
                   if(count==0){
                       prevOL.isEnabled = false
                       
                   }
                   else{
                       prevOL.isEnabled = true
                       
                   }
                   if(count == arr[topic].count-1){
                       nextOL.isEnabled = false
                       
                   }
                   else{
                       nextOL.isEnabled = true
                       
                   }
                   resetOL.isEnabled = true
                }
                else if(!actors_keywords.contains(a) && !animals_keywords.contains(a) && !books_keywords.contains(a)){
                    topic = -1
                    resultImage.image = UIImage(named: "oops")
                    prevOL.isHidden = true
                    nextOL.isHidden = true
                    resetOL.isHidden = true
                    topicInfoText.isHidden = true;
                    
                }
        
    }
    
    
    @IBAction func ShowNextImagesBtn(_ sender: Any) {
        
        count+=1
        imageDisplay(topic, count)
        
    }
    
    
    @IBAction func ShowPrevImagesBtn(_ sender: Any) {
        
        count-=1
        imageDisplay(topic, count)
    }
    
    
    @IBAction func ResetBtn(_ sender: Any) {
        
        searchTextField.text = ""
        searchOL.isEnabled = false
        
        prevOL.isHidden = true
        nextOL.isHidden = true
        resetOL.isHidden = true
        topicInfoText.text = ""
        resultImage.image = UIImage(named: "welcome")
    }
    

    @IBAction func searchField(_ sender: UITextField) {
        if(searchTextField.text!.isEmpty){
            searchOL.isEnabled = false
            prevOL.isHidden = true
            nextOL.isHidden = true
            resetOL.isHidden = true
        }
        else{
            searchOL.isEnabled = true
          
        }
    }
    
    
    
    func imageDisplay(_ firstIndex:Int, _ secondIndex:Int){
        resultImage.image = UIImage(named: arr[topic][count])
        topicInfoText.text = topics_array[topic][count]
        if(count==0){
            prevOL.isEnabled = false
        }
        else{
            prevOL.isEnabled = true
        }
        if(count == arr[topic].count-1){
            nextOL.isEnabled = false
        }
        else{
            nextOL.isEnabled = true
        }
        resetOL.isEnabled = true
    }
    
    
}

