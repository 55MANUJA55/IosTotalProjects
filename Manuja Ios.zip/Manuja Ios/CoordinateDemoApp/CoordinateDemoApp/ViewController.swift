//
//  ViewController.swift
//  CoordinateDemoApp
//
//  Created by Manuja Prasadam on 2/29/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageviewOL: UIImageView!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //identify the minimum opf x and y values of image view
        let minX = imageviewOL.frame.minX
        let minY = imageviewOL.frame.minY
        
        print(minX,",", minY)
        
        //identify the maximum x and y values
        let maxX = imageviewOL.frame.maxX
        let maxY = imageviewOL.frame.maxY
        
        print(maxX,",",maxY)
        
        //identify the mid values of x and y of imageviewOL.
        let midX = imageviewOL.frame.midX
        let midY = imageviewOL.frame.midY
        
        print(midX,",",midY)
        
        //move the image view to the upper left corner of the view
        imageviewOL.frame.origin.x = 0
        imageviewOL.frame.origin.y = 0
        
        // move the image view to the upper right corner of the view
        imageviewOL.frame.origin.x = 330
        imageviewOL.frame.origin.y = 0
        
        // move the image view to the lower left corner of the view
        imageviewOL.frame.origin.x = 0
        imageviewOL.frame.origin.y = 832
        
        // move the image view to the lower right corner of the view
        imageviewOL.frame.origin.x = 330
        imageviewOL.frame.origin.y = 832
        
        // move the image view to the center of the view
        imageviewOL.frame.origin.x = 215
        imageviewOL.frame.origin.y = 466
        
        // move the image view to the upper center of the view
        imageviewOL.frame.origin.x = 165
        imageviewOL.frame.origin.y = 416
        
        
        
    }


}

