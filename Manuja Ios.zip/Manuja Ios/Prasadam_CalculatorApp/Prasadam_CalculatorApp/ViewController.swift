//
//  ViewController.swift
//  Prasadam_CalculatorApp
//
//  Created by Manuja Prasadam on 2/7/24.
//

import UIKit

class ViewController: UIViewController {
    var number1 : Double = 0.0
    var number2 : Double = 0
    var result : Double = 0
    var op = ""
    
    @IBOutlet weak var resultOutlet: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    @IBAction func btnZero(_ sender: Any) {
        resultOutlet.text = ""
        number1 = 0
        number2 = 0
        
    }
    
    @IBAction func btnOne(_ sender: Any) {
        if(!(resultOutlet.text!.isEmpty)){
            resultOutlet.text!.removeLast()
        }
    }
    
    @IBAction func btnTwo(_ sender: Any) {
        if(op == "+"){
            op = "-"
        }else{
            op = "+"
        }
    }
    
    @IBAction func btnThree(_ sender: Any) {
        op = "/"
        number1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    @IBAction func btnFour(_ sender: Any) {
        resultOutlet.text = resultOutlet.text! + "7"
    }
    @IBAction func btnFive(_ sender: Any) {
        resultOutlet.text = resultOutlet.text! + "8"
    }
    @IBAction func btnSix(_ sender: Any) {
        resultOutlet.text = resultOutlet.text! + "9"
    }
    @IBAction func btnSeven(_ sender: Any) {
        op = "*"
        number1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    @IBAction func btnEight(_ sender: Any) {
        resultOutlet.text = resultOutlet.text! + "4"
    }
    @IBAction func btnNine(_ sender: Any) {
        resultOutlet.text = resultOutlet.text! + "5"
    }
    @IBAction func btnTen(_ sender: Any) {
        resultOutlet.text = resultOutlet.text! + "6"
    }
    @IBAction func btneleven(_ sender: Any) {
        op = "-"
        number1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    
    @IBAction func btntwelve(_ sender: Any) {
        resultOutlet.text = resultOutlet.text! + "1"
    }
    @IBAction func btnThirteen(_ sender: Any) {
        resultOutlet.text = resultOutlet.text! + "2"
    }
    @IBAction func btnFourteen(_ sender: Any) {
        resultOutlet.text = resultOutlet.text! + "3"
    }
    @IBAction func btnFiveteen(_ sender: Any) {
        op = "+"
        number1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    @IBAction func btnSixteen(_ sender: Any) {
        resultOutlet.text = resultOutlet.text! + "0"
    }
    @IBAction func btnSeventeen(_ sender: Any) {
        if(!resultOutlet.text!.contains(".")){
            resultOutlet.text = resultOutlet.text! + "."
            return
        }
    }
    @IBAction func btnEighteen(_ sender: Any) {
        op = "%"
        number1 = Double(resultOutlet.text!)!
        resultOutlet.text = ""
    }
    @IBAction func btnNineteen(_ sender: Any) {
        number2 = Double(resultOutlet.text!) ?? 0.0
        switch op {
        case "+":
            result = number1 + number2
            resultOutlet.text = "\(result)"
        case "-":
            result = number1 - number2
            resultOutlet.text = "\(result)"
        case "*":
            result = number1 * number2
            resultOutlet.text = "\(result)"
        case "/":
            result = number1 / number2
            if(number2 == 0){
                resultOutlet.text = "Not a number"
            }
            else{
                let result2 = round(result*100000)/100000.0
                resultOutlet.text = "\(result2)"
            }
        case "%":
            result = number1.truncatingRemainder(dividingBy: number2)
            let result3=round(result*10)/10
            resultOutlet.text = "\(result3)"
        default:
            resultOutlet.text = "Not a number"
        }
        let sresponse = resultOutlet.text!.components(separatedBy: ".")
        let tresponse = resultOutlet.text
        if(!(tresponse == "Not a number")){
            if(sresponse[1]=="0"){
                resultOutlet.text = sresponse[0]
            }
        }
        
    }
}
