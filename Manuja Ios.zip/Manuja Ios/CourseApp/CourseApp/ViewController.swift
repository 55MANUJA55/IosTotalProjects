//
//  ViewController.swift
//  CourseApp
//
//  Created by Manuja Prasadam on 2/22/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var imageOL: UIImageView!
    
    @IBOutlet weak var crsnoOL: UILabel!
    
    @IBOutlet weak var titleOL: UILabel!
    
    @IBOutlet weak var semisterOL: UILabel!
    
    @IBOutlet weak var previousOL: UIButton!
    
    @IBOutlet weak var nextOL: UIButton!
    
    //Populate an array
    let courses = [["img01","44555","Network Security","Fall"],["img02","44666","iOS","Spring"],["img03","46556","Data Streaming","Summer"]]
    var imgNum = 0;
    override func viewDidLoad() {
        
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //previous btn disabled.
        previousOL.isEnabled = false;
        
        //display first course details (index 0)
        updateCourse(imgNum)
        
        
        
    }

    @IBAction func previousBtn(_ sender: Any) {
        //next btn should bve enabled
        nextOL.isEnabled = true
        //decrement the img number
         imgNum = imgNum-1
        
        //update the course
        updateCourse(imgNum)
        
        //once we reach the begining of the array disable the previous btn
        if(imgNum == 0){
            previousOL.isEnabled = false
        }
        
    }
    
    @IBAction func nextBtn(_ sender: Any) {
        //previous btn should be enabled
        previousOL.isEnabled = true;
        
        // increment the img number
        imgNum = imgNum+1
        
        //updating the course details
        updateCourse(imgNum)
        
        
        //once the user reach the end of the array the next btn should be desabled
        if(imgNum == courses.count-1){
            nextOL.isEnabled = false
            
        }
    }//end of previous
    
    func updateCourse(_ imgnumber : Int){
        imageOL.image = UIImage(named: courses[imgnumber][0])
        crsnoOL.text = courses[imgnumber][1]
        titleOL.text = courses[imgnumber][2]
        semisterOL.text = courses[imgnumber][3]
        
    }
    
}

