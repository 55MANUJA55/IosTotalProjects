//
//  MovieInfoViewController.swift
//  Prasadam_MovieApp
//
//  Created by Manuja Prasadam on 4/8/24.
//

import UIKit

class MovieInfoViewController: UIViewController {

    @IBOutlet weak var movieImageViewOutlet: UIImageView!
    
    
    @IBOutlet weak var movieInfoOutlet: UITextView!
    
    
    var moviesInfo = MovieList()
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        self.title = "\(moviesInfo.movieName)"
        
        movieImageViewOutlet.image = UIImage(named: moviesInfo.movieImage)
        var width = movieImageViewOutlet.frame.width
        width += 40
                
        var height = movieImageViewOutlet.frame.height
                height += 40
                
        var x = movieImageViewOutlet.frame.origin.x - 20
        var y = movieImageViewOutlet.frame.origin.y - 20
        var largeFrame = CGRect(x: x, y: y, width: width, height: height)
                UIView.animate(withDuration: 1,delay: 0.4,usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
                    self.movieImageViewOutlet.frame = largeFrame
                })
        movieInfoOutlet.isHidden = true
    }
    
    
    @IBAction func showInfoAction(_ sender: UIButton) {
        
        movieInfoOutlet.isHidden = false
        movieInfoOutlet.text = moviesInfo.movieInfo
        
    }
    
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
