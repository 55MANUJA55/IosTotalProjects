//
//  MovieListViewController.swift
//  Prasadam_MovieApp
//
//  Created by Manuja Prasadam on 4/8/24.
//

import UIKit

class MovieListViewController: UIViewController, UITableViewDelegate, UITableViewDataSource {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.MovieList.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = movieListTableView.dequeueReusableCell(withIdentifier: "listCell", for: indexPath)
        
        cell.textLabel?.text = movies.MovieList[indexPath.row].movieName
        
        return cell
        
        
        
    }
    
    
    var movies = Movies()

    @IBOutlet weak var movieListTableView: UITableView!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        movieListTableView.delegate = self
        movieListTableView.dataSource = self
        
        self.title = movies.genre
        
        
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        var transition = segue.identifier
        
        if(transition == "movieInfoSegue"){
            var destination = segue.destination as! MovieInfoViewController
            
            destination.moviesInfo = movies.MovieList[(movieListTableView.indexPathForSelectedRow?.row)!]
            
        }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
