//
//  ViewController.swift
//  Prasadam_MovieApp
//
//  Created by Manuja Prasadam on 4/8/24.
//

import UIKit

class MoviesViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    
    
    let movies = genreTypes
    
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return movies.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        var cell = moviesTableView.dequeueReusableCell(withIdentifier: "genreCell", for: indexPath)
        cell.textLabel?.text = movies[indexPath.row].genre
        
        return cell
    }
    

    
    @IBOutlet weak var moviesTableView: UITableView!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        moviesTableView.dataSource = self
        moviesTableView.delegate = self
        
        self.title = "Genres"
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if(transition == "listsSegue"){
            var destination = segue.destination as! MovieListViewController
            destination.movies = movies[(moviesTableView.indexPathForSelectedRow?.row)!]
        }
    }


}

