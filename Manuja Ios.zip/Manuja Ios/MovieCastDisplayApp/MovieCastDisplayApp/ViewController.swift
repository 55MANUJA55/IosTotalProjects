//
//  ViewController.swift
//  MovieCastDisplayApp
//
//  Created by Manuja Prasadam on 2/26/24.
//

import UIKit


class ViewController: UIViewController {

    
    @IBOutlet weak var imageOL: UIImageView!
    
    @IBOutlet weak var mnameOL: UILabel!
    
    @IBOutlet weak var directorOL: UILabel!
    
    @IBOutlet weak var heroOL: UILabel!
    
    @IBOutlet weak var heroineOL: UILabel!
    
    @IBOutlet weak var previousOL: UIButton!
    
    @IBOutlet weak var nextOL: UIButton!
    
    let movies = [["daddy","Daddy","Suresh","Chiranjeevi","Simran"],["aaa","A AA","Trivikram","Nithin","Samantha"],["pages","18 pages","Surya Pratap","Nithin","Anupama"],["rrr","RRR","Raja Mouli","NTR & Ram Charan","Olivia"],["jalsa","Jalsa","Trivikram","Pawan Kalyan","Iliyana"]]
    var imgNo = 0;
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        //previous btn disabled.
        previousOL.isEnabled = false;
        
        //display first movie details (index 0)
        updateMovies(imgNo)
    }

    @IBAction func previousBtn(_ sender: Any) {
        //next btn should bve enabled
        nextOL.isEnabled = true
        //decrement the img number
         imgNo = imgNo-1
        
        //update the movie
        updateMovies(imgNo)
        
        //once we reach the begining of the array disable the previous btn
        if(imgNo == 0){
            previousOL.isEnabled = false
        }
    }
    
    
    @IBAction func nextBtn(_ sender: Any) {
        //previous btn should be enabled
        previousOL.isEnabled = true;
        
        // increment the img number
        imgNo = imgNo+1
        
        //updating the movie details
        updateMovies(imgNo)
        
        
        //once the user reach the end of the array the next btn should be desabled
        if(imgNo == movies.count-1){
            nextOL.isEnabled = false
            
        }
    }
    func updateMovies(_ imgnumber : Int){
        imageOL.image = UIImage(named: movies[imgnumber][0])
        mnameOL.text = movies[imgnumber][1]
        directorOL.text = movies[imgnumber][2]
        heroOL.text = movies[imgnumber][3]
        heroineOL.text = movies[imgnumber][4]
        
    }
}

