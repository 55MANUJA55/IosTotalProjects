//
//  ViewController.swift
//  NameApp
//
//  Created by Manuja Prasadam on 2/11/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var Fname: UITextField!
    

    @IBOutlet weak var Lname: UITextField!
    
    @IBOutlet weak var OutputOl: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn(_ sender: Any) {
        var fname = Fname.text!
        var lname = Lname.text!
        
        OutputOl.text = "\(fname.first!) . \(lname.first!) ."
    }
    
}

