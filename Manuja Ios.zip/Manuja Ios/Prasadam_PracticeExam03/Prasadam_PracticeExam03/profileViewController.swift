//
//  profileViewController.swift
//  Prasadam_PracticeExam03
//
//  Created by Manuja Prasadam on 4/16/24.
//

import UIKit

class profileViewController: UIViewController {

    @IBOutlet weak var initialsOL: UILabel!
    
    
    @IBOutlet weak var phoneNumberOL: UILabel!
    
    var name = ""
    var name2 = ""
    var phone = ""
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        initialsOL.text = "intials: \(name.first!). \(name2.first!)"
        phoneNumberOL.text = "Phone Number:  \(phone)"
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
