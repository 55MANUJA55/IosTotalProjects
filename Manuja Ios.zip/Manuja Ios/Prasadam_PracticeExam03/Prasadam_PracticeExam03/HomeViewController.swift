//
//  ViewController.swift
//  Prasadam_PracticeExam03
//
//  Created by Manuja Prasadam on 4/16/24.
//

import UIKit


class Contact{
    var FirstName : String?
    var LastName  : String?
    var PhoneNumber : String?
    
    
    
    init(FirstName: String, LastName: String, PhoneNumber: String) {
        self.FirstName = FirstName
        self.LastName = LastName
        self.PhoneNumber = PhoneNumber
    }
}

class HomeViewController: UIViewController, UITableViewDataSource, UITableViewDelegate {
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return contactinfo.count
    }
    
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell = TableViewOL.dequeueReusableCell(withIdentifier: "contactCell", for: indexPath)
        cell.textLabel?.text = "\(contactinfo[indexPath.row].FirstName!) \(contactinfo[indexPath.row].LastName!)"
        return cell
    }
    

    @IBOutlet weak var TableViewOL: UITableView!
    
    
    var contactinfo = [Contact]()
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
        
        
        let c1 = Contact(FirstName: "John", LastName: "Abraham", PhoneNumber: "123-456-789")
        contactinfo.append(c1)
        let c2 = Contact(FirstName: "Ram", LastName: "Krishna", PhoneNumber: "123-456-689")
        contactinfo.append(c2)
        let c3 = Contact(FirstName: "Hari", LastName: "Krishna", PhoneNumber: "123-456-589")
        contactinfo.append(c3)
        let c4 = Contact(FirstName: "Rajesh", LastName: "Mani", PhoneNumber: "123-456-489")
        contactinfo.append(c4)
        let c5 = Contact(FirstName: "Sitha", LastName: "Maheswari", PhoneNumber: "123-456-389")
        contactinfo.append(c5)
        let c6 = Contact(FirstName: "Chandan", LastName: "Viavila", PhoneNumber: "123-456-289")
        contactinfo.append(c6)
        let c7 = Contact(FirstName: "Harish", LastName: "Viavila", PhoneNumber: "123-456-189")
        contactinfo.append(c7)
        let c8 = Contact(FirstName: "Rakesh", LastName: "Raj", PhoneNumber: "123-456-889")
        contactinfo.append(c8)
        let c9 = Contact(FirstName: "Bharat", LastName: "Vemu", PhoneNumber: "123-456-989")
        contactinfo.append(c9)
        let c10 = Contact(FirstName: "Raju", LastName: "Mopar", PhoneNumber: "123-456-109")
        contactinfo.append(c10)
        
        TableViewOL.delegate = self
        TableViewOL.dataSource = self
        
        self.title = "Contacts"
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        if(transition == "ContactSegue"){
            let destination = segue.destination as! profileViewController
            
            let index = TableViewOL.indexPathForSelectedRow
            destination.name = contactinfo[index!.row].FirstName!
            destination.name2 = contactinfo[index!.row].LastName!
            destination.phone = contactinfo[index!.row].PhoneNumber!
                    }
    }


}

