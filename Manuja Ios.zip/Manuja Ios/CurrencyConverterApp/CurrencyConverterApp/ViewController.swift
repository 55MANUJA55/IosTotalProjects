//
//  ViewController.swift
//  CurrencyConverterApp
//
//  Created by Manuja Prasadam on 2/11/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var amount: UITextField!
    
    @IBOutlet weak var rate: UITextField!
    
    @IBOutlet weak var output: UILabel!
    
    @IBOutlet weak var image: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func btn(_ sender: Any) {
        var money = Int(amount.text!)
        var Rate = Int(rate.text!)
        var total = money!*Rate!
        
        output.text = "\(total)"
        image.image = UIImage(named: "india.jpeg")
        
    }
    
}

