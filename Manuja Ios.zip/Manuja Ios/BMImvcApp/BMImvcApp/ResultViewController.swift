//
//  ResultViewController.swift
//  BMImvcApp
//
//  Created by Manuja Prasadam on 3/26/24.
//

import UIKit

class ResultViewController: UIViewController {
    
    @IBOutlet weak var imageOL: UIImageView!
    
    
    @IBOutlet weak var WeightOL: UILabel!
    
    @IBOutlet weak var BMIOL: UILabel!
    
    @IBOutlet weak var ResultOL: UILabel!
    
    @IBOutlet weak var HeightOL: UILabel!
    var image = ""
    var height = 0.0
    var weight = 0.0
    var result = ""
    var bmi = 0.0
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        imageOL.image = UIImage(named: image)
        HeightOL.text = "Height: \(height)"
        WeightOL.text = "Weight: \(weight)"
        BMIOL.text = "Calculated BMI: \(bmi)"
        ResultOL.text = "Result: \(result)"
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
