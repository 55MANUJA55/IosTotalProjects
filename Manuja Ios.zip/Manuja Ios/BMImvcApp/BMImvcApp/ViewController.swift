//
//  ViewController.swift
//  BMImvcApp
//
//  Created by Manuja Prasadam on 3/26/24.
//

import UIKit

class ViewController: UIViewController {
    var height = 0.0
    var weight = 0.0
    var bmi = 0.0
    var image = ""
    var result = ""
    
    @IBOutlet weak var weightOL: UITextField!
    
    @IBOutlet weak var HeightOL: UITextField!
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func CheckBmi(_ sender: Any) {
        
        height = Double(HeightOL.text!)!
        weight = Double(weightOL.text!)!
        bmi = (703*weight)/(height*height)
        
        if (bmi < 18.5){
            result = "underweight"
            image = "under"
        }
        else if (bmi < 30.0){
            result = "overweight"
            image = "overWeight"
        }else if (bmi < 25.0){
            result = "Normal"
            image = "normal"
        }else{
            result = "obesity"
            image = "obesity"
        }
    }
        override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
            //know the identifier
            let transition = segue.identifier
            //set the destination
            if(transition == "BMISegue"){
                let destination  = segue.destination as! ResultViewController
                //assign the values to the destination variables
                destination.image = image
                destination.result = result
                destination.height = height
                destination.weight = weight
                destination.bmi = bmi
                
            }
        
            
        }
    }
        
    
    


