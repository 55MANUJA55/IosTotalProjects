//
//  ViewController.swift
//  Prasadam_PracticeExam02
//
//  Created by Manuja Prasadam on 4/9/24.
//

import UIKit


var totalMonths = 0.00
var monthlyInterestRate = 0.00
var monthlyEMIPayment = 0.00

var type = ""
var amount = ""
var rate = ""
var emi : Double = 0.00
var image = ""

class HomeViewController: UIViewController {
    
    @IBOutlet weak var loanTypeOL: UITextField!
    
    
    @IBOutlet weak var loanAmountOL: UITextField!
    
    
    @IBOutlet weak var intrestOL: UITextField!
    

    @IBOutlet weak var yearOL: UITextField!
    
    
    @IBOutlet weak var rbtnOL: UIButton!
    
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        
       
        
    }
    
    
    
    @IBAction func calBtn(_ sender: Any) {
        
        
        
        totalMonths = (Double(yearOL.text!)! * 12)
        monthlyInterestRate = Double(intrestOL.text!)! / 12
        var mo = monthlyInterestRate / 100
        
        monthlyEMIPayment = Double( loanAmountOL.text!)! * (mo * pow(1+mo,totalMonths)) / (pow(1+mo, totalMonths) - 1)
        
        if(loanTypeOL.text! == "Car"){
            
             type = loanTypeOL.text!
            amount = loanAmountOL.text!
             rate = intrestOL.text!
             emi = monthlyEMIPayment
             image = "Car"
            }
        else if(loanTypeOL.text! == "Personal"){
            
            type = loanTypeOL.text!
            amount = loanAmountOL.text!
            rate = intrestOL.text!
            emi = monthlyEMIPayment
            image = "Personal"
            }
        else if(loanTypeOL.text! == "Home"){
            
            type = loanTypeOL.text!
            amount = loanAmountOL.text!
            rate = intrestOL.text!
            emi = monthlyEMIPayment
            image = "Home"
            }
        
                
        
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let transition = segue.identifier
        
        if(transition == "result"){
            let destination = segue.destination as! ResultViewController
            
            destination.image = image
            destination.type = type
            destination.rate = rate
            destination.emi = emi
            destination.amount = amount
        }
    }
    
    
    @IBAction func resetBtn(_ sender: Any) {
        
        loanTypeOL.text! = ""
        loanAmountOL.text! = ""
        intrestOL.text! = ""
        yearOL.text! = ""
        
    }
    

}

