//
//  ResultViewController.swift
//  Prasadam_PracticeExam02
//
//  Created by Manuja Prasadam on 4/9/24.
//

import UIKit



class ResultViewController: UIViewController {
    
    var type = ""
    var amount = ""
    var rate = ""
    var emi : Double = 0.00
    var image = ""
    
    
    @IBOutlet weak var LtypeOL: UILabel!
    
    
    @IBOutlet weak var amountOL: UILabel!
    
    
    @IBOutlet weak var rateOL: UILabel!
    
    
    @IBOutlet weak var tOL: UILabel!
    
    
    
    @IBOutlet weak var imgOL: UIImageView!
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
        
        imgOL.image = UIImage(named: image)
        amountOL.text = amount
        LtypeOL.text = type
        rateOL.text = rate
        tOL.text = String(emi)
        
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destination.
        // Pass the selected object to the new view controller.
    }
    */

}
