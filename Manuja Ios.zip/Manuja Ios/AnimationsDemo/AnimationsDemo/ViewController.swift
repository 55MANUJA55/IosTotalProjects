//
//  ViewController.swift
//  AnimationsDemo
//
//  Created by Manuja Prasadam on 3/7/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var imageViewOL: UIImageView!
    
    @IBOutlet weak var showmeOL: UIButton!
    
    @IBOutlet weak var happyOL: UIButton!
    
    @IBOutlet weak var sadOL: UIButton!
    
    
    @IBOutlet weak var angryOL: UIButton!
    
    
    @IBOutlet weak var shakeOL: UIButton!
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }
    
    override func viewDidAppear(_ animated: Bool) {
      //keep all the components outside of the view
        
        imageViewOL.frame.origin.x = view.frame.width
        happyOL.frame.origin.x = view.frame.width
        sadOL.frame.origin.x = view.frame.width
        angryOL.frame.origin.x = view.frame.width
        shakeOL.frame.origin.x = view.frame.width
    }
    
    

    @IBAction func happybtn(_ sender: Any) {
        UpdateandAnimate("happy")
        
    }
    
    @IBAction func sadbtn(_ sender: Any) {
        UpdateandAnimate("sad")
        
    }
    
    @IBAction func angrybtn(_ sender: Any) {
        UpdateandAnimate("angry")
        
    }
    
    @IBAction func shakebtn(_ sender: Any) {
        
        //increase size of the image
        
        var width = imageViewOL.frame.width
        width += 40
        
        var height = imageViewOL.frame.height
        height += 40
        
        var x = imageViewOL.frame.origin.x
        x  -= 20
        
        var y = imageViewOL.frame.origin.y
        y -= 20
        
        var largeFrame  = CGRect(x: x, y: y, width: width, height: height)
        
        UIView.animate(withDuration: 1, delay: 0, usingSpringWithDamping: 0.4, initialSpringVelocity: 50, animations: {
            self.imageViewOL.frame = largeFrame
        })
        
        
    }
    
    @IBAction func showbtn(_ sender: Any) {
        //move all the componants from outside of the view to center of the view
        UIView.animate(withDuration: 1, animations: {
            self.imageViewOL.center.x = self.view.center.x
            self.happyOL.center.x = self.view.center.x
            self.sadOL.center.x = self.view.center.x
            self.angryOL.center.x = self.view.center.x
            self.shakeOL.center.x = self.view.center.x
        })
        
        //disable the show button
        showmeOL.isEnabled = false
    }
    
    func UpdateandAnimate(_ image:String){
        //making the current image as opaque(alpha = 0)
        UIView.animate(withDuration: 1, animations: {
            self.imageViewOL.alpha = 0
        })
        
        //Assigning the new image with an animation and make it transparent(alpha = 1)
        UIView.animate(withDuration: 1, delay: 0.5, animations: {
            self.imageViewOL.alpha = 1
            self.imageViewOL.image = UIImage(named: image)
        })
        
    }
    
    
}

