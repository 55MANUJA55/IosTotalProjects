//
//  ViewController.swift
//  Prasadam_WordGuess
//
//  Created by Manuja Prasadam on 3/5/24.
//

import UIKit

class ViewController: UIViewController {
    
    @IBOutlet weak var wordsGuessedLabel: UILabel!
    
    @IBOutlet weak var wordsRemainingLabel: UILabel!
    
    @IBOutlet weak var totalWordsLabel: UILabel!
    
    @IBOutlet weak var userGuessLabel: UILabel!
    
    @IBOutlet weak var guessLetterField: UITextField!
    
    @IBOutlet weak var hintLabel: UILabel!
    
    @IBOutlet weak var statusLabel: UILabel!
    
    @IBOutlet weak var displayImage: UIImageView!
    
    @IBOutlet weak var guessCountLabel: UILabel!
    
    @IBOutlet weak var guessOL: UIButton!
    
    @IBOutlet weak var PlayAgainOL: UIButton!
    
    let words = [["apple","A popular fruit"],["bananas","A yellow tropiocal fruit"],["carrot","A crunchy orange vegetables"],["elephant","A large gray animal with a trunk"],["guitar","A musical instrument with strings"]]
    
    var word = ""
    var count = 0
    var letters = ""
    var maxNumOfWrongGuesses = 10
    var max = 0
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        guessOL.isEnabled = false
        
        word = words[count][0]
        
        hintLabel.text = "Hint: "+words[count][1]
        
        updateUnderScore();
        
        statusLabel.isHidden = true
        
        totalWordsLabel.text! += "\(words.count)"
        
        wordsGuessedLabel.text! += "\(max)"
        
        wordsRemainingLabel.text! += "\(word.count)"
    }
    
    
    
    @IBAction func textAction(_ sender: Any) {
        var textEntered = guessLetterField.text!
        
        textEntered = String(textEntered.last ?? " ").trimmingCharacters(in: .whitespaces)
        
        guessLetterField.text = textEntered
        
        if !textEntered.isEmpty{
            guessOL.isEnabled = true
        }
        else{
            guessOL.isEnabled = false
        }
    }
    
    @IBAction func guessLetterButtonPressed(_ sender: Any) {
        let letter = guessLetterField.text!
          
        max+=1
             //Replace the guessed letter if the letter is part of the word.
        hintLabel.isHidden = false
        hintLabel.isEnabled = true
        letters = letters + letter
        guessCountLabel.isHidden =  false
        guessCountLabel.isEnabled = true
              var revealedWord = ""
             for l in word{
                 if letters.contains(l.uppercased()){
                     revealedWord += "\(l.uppercased())"
                 }
                 else{
                     revealedWord += "_ "
                 }
             }
        guessCountLabel.text = "You have made \(max) guesses"
             //Assigning the word to displaylabel after a guess
             userGuessLabel.text = revealedWord
             guessLetterField.text = ""
             
             //If the word is guessed correctly, we are enabling play again button and disabling the check button.
             if userGuessLabel.text!.contains("_") == false{
                 PlayAgainOL.isHidden = false;
                 displayImage.image = UIImage(named: words[count][0])
                 guessCountLabel.text = "Wow! You have made \(max) guesses to guess the word!"
                 count+=1
                 let remaining = words.count - count
                 wordsGuessedLabel.text = "Total number of words guessed successfully: \(count)"
                 wordsRemainingLabel.text = "Total number of words remaining in game: \(remaining)"
                 guessOL.isEnabled = false;
                 count-=1
             }
        
        if(max == maxNumOfWrongGuesses){
            guessCountLabel.text = "You have used all the available guesses, Please play again"
            guessOL.isEnabled = false
            hintLabel.isHidden = true
            count-=1
            PlayAgainOL.isHidden = false
            PlayAgainOL.isEnabled = true
            
        }
        guessOL.isEnabled = false
    }
    
    @IBAction func playAgainButtonPressed(_ sender: Any) {
        max = 0
        count+=1
        let remaining = words.count - count
        userGuessLabel.isHidden = false
        userGuessLabel.isEnabled=true
        statusLabel.isHidden = true
        PlayAgainOL.isEnabled = true
        displayImage.image = UIImage()
        letters = ""
        hintLabel.isHidden = false
        guessCountLabel.text = "You have made \(max) guesses"
        wordsGuessedLabel.text = "Total number of words guessed successfully: \(count)"
        wordsRemainingLabel.text = "Total number of words remaining in game: \(remaining)"
        
        
        if count==words.count{
            statusLabel.isHidden = false
            statusLabel.text = "Congratulations, You are done, Please start over again"
          //  displayImage.image
            guessCountLabel.isHidden = true
            displayImage.image = UIImage(named: "done")
            count = -1
            userGuessLabel.isHidden = true
            hintLabel.isHidden = true
          //  let remaining = words.count - cnt
            wordsGuessedLabel.text = "Total number of words guessed successfully: 0"
            wordsRemainingLabel.text = "Total number of words remaining in game: \(words.count)"
            
        }
        else{
            word = words[count][0]
            
            hintLabel.text = "Hint: " + words[count][1]
            
            guessOL.isEnabled = true
            
            updateUnderScore()
            
            PlayAgainOL.isHidden = true
        }
    }
    func updateUnderScore() {
        userGuessLabel.text = ""
        for i in word{
            //assigning _ for every letter in the word
            userGuessLabel.text! += "_ "
        }
        
    }
    
    
}

