//
//  ViewController.swift
//  Prasadam_Assignment02
//
//  Created by Manuja Prasadam on 1/30/24.
//

import UIKit

class ViewController: UIViewController {

    @IBOutlet weak var nameOutlet: UITextField!
    
    @IBOutlet weak var billAmountOutlet: UITextField!
    
    @IBOutlet weak var tipPercentageOutlet: UITextField!
    
    @IBOutlet weak var dateOutlet: UIDatePicker!
    
    @IBOutlet weak var dateLabel: UILabel!
    
    @IBOutlet weak var nameLabel: UILabel!
    
    @IBOutlet weak var billAmountLabel: UILabel!
    
    @IBOutlet weak var tipAmountLabel: UILabel!
    
    @IBOutlet weak var totalAmountLabel: UILabel!
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    @IBAction func SubmitBTN(_ sender: UIButton) {
        var date=dateOutlet.date
        let dateFormatter = DateFormatter()
        dateFormatter.dateFormat = "MM-dd-yyyy hh:mm"
        dateFormatter.timeZone = TimeZone(identifier: "America/Chicago")
        dateLabel.text = "\(dateFormatter.string(from: date))"
        //dateLabel.text = "\(date)"
        nameLabel.text = "Name: \(nameOutlet.text!)"
        var billAmount = Double(billAmountOutlet.text!)
        var tipAmount = Double(tipPercentageOutlet.text!)
       var TotaltipAmount = (billAmount! * tipAmount!)/100
        var TotalAmount = billAmount! + TotaltipAmount
        billAmountLabel.text = "Bill Amount: $\(billAmount!)"
        tipAmountLabel.text = "Tip Amount: $\(TotaltipAmount)"
        totalAmountLabel.text = "Total Amount: $\(TotalAmount)"
        
        
    }
    
    @IBAction func ResetBTN(_ sender: UIButton) {
        nameOutlet.text = ""
        billAmountOutlet.text = ""
        tipPercentageOutlet.text = ""
        nameLabel.text = ""
        billAmountLabel.text = ""
        totalAmountLabel.text = ""
        tipAmountLabel.text = ""
        dateLabel.text = ""
    }
}

